var searchData=
[
  ['getquestion',['getQuestion',['../quiz_8c.html#a61b019ea0d6811cea047b70cb932bb88',1,'getQuestion(Question *t, int q):&#160;quiz.c'],['../quiz_8h.html#a61b019ea0d6811cea047b70cb932bb88',1,'getQuestion(Question *t, int q):&#160;quiz.c']]]
];
