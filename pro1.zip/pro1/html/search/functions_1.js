var searchData=
[
  ['quiz_5finit',['QUIZ_Init',['../quiz_8c.html#a453393bc1bc7917b087fb016d49fc881',1,'QUIZ_Init(Quiz *q, char *filename):&#160;quiz.c'],['../quiz_8h.html#a453393bc1bc7917b087fb016d49fc881',1,'QUIZ_Init(Quiz *q, char *filename):&#160;quiz.c']]]
];
