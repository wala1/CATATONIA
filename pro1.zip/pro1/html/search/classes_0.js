var searchData=
[
  ['question',['Question',['../structQuestion.html',1,'']]],
  ['quiz',['Quiz',['../structQuiz.html',1,'']]]
];
