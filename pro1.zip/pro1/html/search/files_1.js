var searchData=
[
  ['quiz_2ec',['quiz.c',['../quiz_8c.html',1,'']]],
  ['quiz_2eh',['quiz.h',['../quiz_8h.html',1,'']]]
];
