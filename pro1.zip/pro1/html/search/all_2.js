var searchData=
[
  ['question',['Question',['../structQuestion.html',1,'']]],
  ['quiz',['Quiz',['../structQuiz.html',1,'']]],
  ['quiz_2ec',['quiz.c',['../quiz_8c.html',1,'']]],
  ['quiz_2eh',['quiz.h',['../quiz_8h.html',1,'']]],
  ['quiz_5finit',['QUIZ_Init',['../quiz_8c.html#a453393bc1bc7917b087fb016d49fc881',1,'QUIZ_Init(Quiz *q, char *filename):&#160;quiz.c'],['../quiz_8h.html#a453393bc1bc7917b087fb016d49fc881',1,'QUIZ_Init(Quiz *q, char *filename):&#160;quiz.c']]]
];
