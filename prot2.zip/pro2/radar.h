#ifndef RADAR_H_INCLUDED
#define RADAR_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <string.h>




void miniMap (SDL_Surface *screen , SDL_Rect pos_perso, char mini_background[],char mini_perso[] ,SDL_Rect camera );
#endif /* FONCTIONS_H_ */
